This IPython notebook slides1.ipynb does not require any additional
programs.
